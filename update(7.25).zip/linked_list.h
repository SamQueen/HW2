#include <iostream>
#include <string>
#include <cmath>

using namespace std;

#ifndef SOME_HEADER_GUARD_WITH_UNIQUE_NAME
#define SOME_HEADER_GUARD_WITH_UNIQUE_NAME

//create a struct function for a Node
struct Node
{
    //each Node will carry the following:
    string key;                 //a unique word given by the input file
    struct Node* next;          //a link chain to the next Node
};

#endif