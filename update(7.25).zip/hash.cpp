#include <iostream>
#include <string>
#include "hash.h"

#include "linked_list.h"

using namespace std;

//default function given
//added parameter: int key
//function will appropriately give each key a slot number
//using the sum of each character's ASCII value
int hash_function(string text, int key)
{
    // Implement your own hash function here

    //initialize ASCII variable
    int asciiValue = 0;

    //iterate through each character of the passed in word
    for (int i = 0; i < text.length(); i++)
    {
        //add the ASCII value into the ASCII sum variable
        asciiValue += int(text[i]);
    }

    //return modulo value divided by the length of the slot of the hash table
    return asciiValue % key;
}

//prints the first key elements of the hash table
void printHashTable(Node** head, int key)
{
    //iterate through each slot
    for(int i = 0; i < key; i++)
    {
        //select the begining Node of each linked list
        Node* temp = *(head + i);

        //print according to specification
        cout << "Slot " << i << ": ";

        //continue until the current Node is NULL
        while(temp != NULL)
        {
            //print each Node's key
            cout << temp->key << " ";

            //move on to next Node
            temp = temp->next;
        }

        //newline
        cout << endl;
    }
}

//prints the size of each linked list in the hash table
void printSlots(Node** head, int key)
{
    for(int i = 0; i < key; i++)
    {
        //select the begining Node of each linked list
        Node* temp = *(head + i);

        //print according to specification
        cout << "Slot " << i << ": ";

        //initialize variable that will count the number of Nodes in a linked list
        int count = 0;

        //continue until the current Node is NULL
        while (temp != NULL)
        {
            //increment variable count
            count++;

            //move on to next Node
            temp = temp->next;
        }

        //print count and newline
        cout << count << endl;
    }
}

//returns the deviation of the whole hash table
double deviation(Node** head, int key)
{
    //instantiate variables to be used for calculating mean
    double mean;
    int total = 0;

    //find the mean by adding up all the Node keys' of each slot
    for(int i = 0; i < key; i++)
    {
        //select the begining Node of each linked list
        Node* temp = *(head + i);

        //continue until the current Node is NULL
        while(temp != NULL)
        {
            //increment total to account for Node
            total++;

            //iterate to next Node
            temp = temp->next;
        }
    }

    //calculate the mean using updated variables
    mean = (double)total/key;

    //instantiate variables to be used for calculating variance
    //double variance;
    //double differences = 0;
    //double differences_squared = 0;
    double standardDeviation = 0.0;

    //find the mean by adding up all the Node's keys' of each slot
    for(int i = 0; i < key; i++)
    {
        //select the begining Node of each linked list
        Node* temp = *(head + i);

        //create variable count for each slot iteration
        int count = 0;

        //continue until the current Node is NULL
        while(temp != NULL)
        {
            //increment count to account for Node
            count++;

            //iterate to next Node
            temp = temp->next;
        }

        //calculate standard deviation
        standardDeviation += ((count - mean)*(count - mean));
    }

    //return variance
    return standardDeviation/key;
}