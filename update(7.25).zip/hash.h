#include <iostream>
#include <string>
#include <cmath>

// You are free to use additional libraries as long as it's not BANNED per instruction.

#include "linked_list.h"

using namespace std;

//following functions are defined and described in full in hash.cpp
int hash_function(string text, int key);
void printHashTable(Node** head, int key);
void printSlots(Node** head, int key);
double deviation(Node** head, int key);