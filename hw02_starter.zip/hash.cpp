#include <iostream>
#include <string>
#include "hash.h"

using namespace std;

int hash_function(string text) {
    // Implement your own hash function here
    return 1;
}